==> Xlight Bootstrap Responsive HTML5/CSS3 Template

==> Copyright (c) 2017 Andsolutions.it


==> Ver 1.00


Html Created by: https://www.andsolutions.it




Main Feautures:

- Dark and White Version
- CSS3, HTML5, Responsive
- Made with Bootstrap Framework
- Font Awesome 4.7
- 8 Different Main Color (Blue, Green, Yellow, Purple, Magenta, Orange, Pink, Golden, Dark Blue)
- Parallax Effect
- Parallax Slider
- Filterable Portfolio with gallery
- Portfolio extra page (image, slider, vimeo video, youtube video)
- Profiles extra page
- php/ajax Validate Form
- Animations
- Blog Pages
- Typography



Rights: 
You are permitted to use the resources for any number of personal and commercial projects.
You may modify the resources according to your requirements and include them into works, 
such as websites, applications or other materials intended for sale. No attribution or 
link back to this site is required, however any credit will be much appreciated.





Thanks